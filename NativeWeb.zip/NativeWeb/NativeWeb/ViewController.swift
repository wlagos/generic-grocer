//
//  ViewController.swift
//  CDCNativeTest
//

import UIKit
import Gigya
import CryptoKit

// Custom Gigya data schema — mirrors res.data in gigya.accounts.getAccountInfo callback.
struct CDCGigyaData: Codable {
    var ARTS_CUST_KEY: String?
}

// Custom account type that carries CDCGigyaData so account.data?.ARTS_CUST_KEY is accessible.
struct CDCAccount: GigyaAccountProtocol {
    var UID: String?
    var profile: GigyaProfile?
    var UIDSignature: String?
    var apiVersion: Int?
    var created: String?
    var createdTimestamp: Double?
    var isActive: Bool?
    var isRegistered: Bool?
    var isVerified: Bool?
    var lastLogin: String?
    var lastLoginTimestamp: Double?
    var lastUpdated: String?
    var lastUpdatedTimestamp: Double?
    var loginProvider: String?
    var oldestDataUpdated: String?
    var oldestDataUpdatedTimestamp: Double?
    var registered: String?
    var registeredTimestamp: Double?
    var signatureTimestamp: String?
    var socialProviders: String?
    var verified: String?
    var verifiedTimestamp: Double?
    var data: CDCGigyaData?
}

class ViewController: UIViewController {

    // MARK: - Home Page UI

    private let scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()

    private let contentView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let logoImageView: UIImageView = {
        let iv = UIImageView(image: UIImage(named: "CC2GO"))
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let welcomeLabel: UILabel = {
        let label = UILabel()
        label.text = "WELCOME BACK!"
        label.font = UIFont.boldSystemFont(ofSize: 22)
        label.textAlignment = .center
        label.textColor = .black
        return label
    }()

    private let subtitleLabel: UILabel = {
        let label = UILabel()
        label.text = "Sign in below to start shopping, view coupons, and more with your Username (Enter an e-mail address)."
        label.font = UIFont.systemFont(ofSize: 14)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = UIColor(white: 0.45, alpha: 1)
        return label
    }()

    private let signInButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Sign In", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        button.backgroundColor = UIColor(red: 0.18, green: 0.43, blue: 0.71, alpha: 1.0)
        button.layer.cornerRadius = 4
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let forgotPasswordButton: UIButton = {
        let button = UIButton(type: .system)
        let full = "Forgot your Password? Recover Password"
        let attr = NSMutableAttributedString(string: full)
        let range = (full as NSString).range(of: "Recover Password")
        let gray = UIColor(white: 0.45, alpha: 1)
        let blue = UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 1.0)
        attr.addAttribute(.foregroundColor, value: gray,
                          range: NSRange(location: 0, length: full.count - range.length - 1))
        attr.addAttribute(.foregroundColor, value: blue, range: range)
        attr.addAttribute(.font, value: UIFont.systemFont(ofSize: 13), range: NSRange(location: 0, length: full.count))
        button.setAttributedTitle(attr, for: .normal)
        button.titleLabel?.textAlignment = .center
        return button
    }()

    private let separatorView: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 0.8, alpha: 1)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let createAccountButton: UIButton = {
        let button = UIButton(type: .system)
        let full = "FIRST TIME HERE?  Create An Account"
        let attr = NSMutableAttributedString(string: full)
        let range = (full as NSString).range(of: "Create An Account")
        let blue = UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 1.0)
        attr.addAttribute(.foregroundColor, value: UIColor.black,
                          range: NSRange(location: 0, length: full.count - range.length - 2))
        attr.addAttribute(.foregroundColor, value: blue, range: range)
        attr.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 13), range: NSRange(location: 0, length: full.count))
        button.setAttributedTitle(attr, for: .normal)
        button.titleLabel?.textAlignment = .center
        return button
    }()

    private let privilegeLabel: UILabel = {
        let label = UILabel()
        label.text = "Users must have Commissary shopping privileges to create an account."
        label.font = UIFont.systemFont(ofSize: 12)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = UIColor(white: 0.45, alpha: 1)
        return label
    }()

    private let liteSeparatorView: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 0.8, alpha: 1)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()

    private let liteRegistrationButton: UIButton = {
        let button = UIButton(type: .system)
        let full = "NOT A COMMISSARY PATRON?  Subscribe with Email"
        let attr = NSMutableAttributedString(string: full)
        let range = (full as NSString).range(of: "Subscribe with Email")
        let blue = UIColor(red: 0.0, green: 0.48, blue: 1.0, alpha: 1.0)
        attr.addAttribute(.foregroundColor, value: UIColor.black,
                          range: NSRange(location: 0, length: full.count - range.length - 2))
        attr.addAttribute(.foregroundColor, value: blue, range: range)
        attr.addAttribute(.font, value: UIFont.boldSystemFont(ofSize: 13), range: NSRange(location: 0, length: full.count))
        button.setAttributedTitle(attr, for: .normal)
        button.titleLabel?.textAlignment = .center
        return button
    }()

    // MARK: - Logged-In UI

    private let loggedInLogoImageView: UIImageView = {
        let iv = UIImageView(image: UIImage(named: "CC2GO"))
        iv.contentMode = .scaleAspectFit
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let welcomeNameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 22)
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()

    private let accountDetailsLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 15)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = UIColor(white: 0.45, alpha: 1)
        return label
    }()

    private let updateProfileButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Update Profile", for: .normal)
        button.setTitleColor(UIColor(red: 0.18, green: 0.43, blue: 0.71, alpha: 1.0), for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let logoutButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Log Out", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        button.backgroundColor = UIColor(red: 0.18, green: 0.43, blue: 0.71, alpha: 1.0)
        button.layer.cornerRadius = 4
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private lazy var loggedInStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [
            loggedInLogoImageView, welcomeNameLabel, accountDetailsLabel, updateProfileButton, logoutButton
        ])
        stack.axis = .vertical
        stack.spacing = 20
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()

    // MARK: - Toast Banner

    private func showToastBanner(_ message: String) {
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let window = scene.windows.max(by: { $0.windowLevel < $1.windowLevel }) else { return }

        let banner = UIView()
        banner.backgroundColor = UIColor.systemGreen
        banner.layer.cornerRadius = 8
        banner.layer.shadowColor = UIColor.black.cgColor
        banner.layer.shadowOpacity = 0.15
        banner.layer.shadowOffset = CGSize(width: 0, height: 2)
        banner.layer.shadowRadius = 4
        banner.translatesAutoresizingMaskIntoConstraints = false

        let label = UILabel()
        label.text = message
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false

        banner.addSubview(label)
        window.addSubview(banner)

        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: banner.topAnchor, constant: 12),
            label.bottomAnchor.constraint(equalTo: banner.bottomAnchor, constant: -12),
            label.leadingAnchor.constraint(equalTo: banner.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: banner.trailingAnchor, constant: -16),

            banner.topAnchor.constraint(equalTo: window.safeAreaLayoutGuide.topAnchor, constant: 12),
            banner.leadingAnchor.constraint(equalTo: window.leadingAnchor, constant: 16),
            banner.trailingAnchor.constraint(equalTo: window.trailingAnchor, constant: -16),
        ])

        banner.alpha = 0
        UIView.animate(withDuration: 0.3) { banner.alpha = 1 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            UIView.animate(withDuration: 0.3, animations: { banner.alpha = 0 }) { _ in
                banner.removeFromSuperview()
            }
        }
    }

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupHomePageUI()
        setupLoggedInUI()

        signInButton.addTarget(self, action: #selector(openScreenSet), for: .touchUpInside)
        forgotPasswordButton.addTarget(self, action: #selector(openScreenSet), for: .touchUpInside)
        createAccountButton.addTarget(self, action: #selector(openRegistrationScreen), for: .touchUpInside)
        liteRegistrationButton.addTarget(self, action: #selector(openLiteRegistration), for: .touchUpInside)
        updateProfileButton.addTarget(self, action: #selector(openUpdateProfile), for: .touchUpInside)
        logoutButton.addTarget(self, action: #selector(logout), for: .touchUpInside)

        // Hide logged-in state until a valid session is confirmed.
        loggedInStack.isHidden = true

        if Gigya.sharedInstance(CDCAccount.self).isLoggedIn() {
            fetchAndShowAccount()
        } else {
            showLoggedOutState()
        }
    }

    // MARK: - Layout

    private func setupHomePageUI() {
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        let formCard = UIView()
        formCard.backgroundColor = .white
        formCard.layer.cornerRadius = 8
        formCard.layer.borderColor = UIColor(white: 0.88, alpha: 1).cgColor
        formCard.layer.borderWidth = 1
        formCard.layer.shadowColor = UIColor.black.cgColor
        formCard.layer.shadowOpacity = 0.08
        formCard.layer.shadowOffset = CGSize(width: 0, height: 2)
        formCard.layer.shadowRadius = 6
        formCard.translatesAutoresizingMaskIntoConstraints = false

        let cardStack = UIStackView(arrangedSubviews: [
            welcomeLabel,
            subtitleLabel,
            signInButton,
            forgotPasswordButton,
            separatorView,
            createAccountButton,
            privilegeLabel,
            liteSeparatorView,
            liteRegistrationButton
        ])
        cardStack.axis = .vertical
        cardStack.spacing = 16
        cardStack.alignment = .fill
        cardStack.translatesAutoresizingMaskIntoConstraints = false
        cardStack.setCustomSpacing(24, after: subtitleLabel)
        cardStack.setCustomSpacing(24, after: signInButton)
        cardStack.setCustomSpacing(20, after: forgotPasswordButton)
        cardStack.setCustomSpacing(20, after: separatorView)
        cardStack.setCustomSpacing(20, after: privilegeLabel)
        cardStack.setCustomSpacing(20, after: liteSeparatorView)

        formCard.addSubview(cardStack)
        contentView.addSubview(logoImageView)
        contentView.addSubview(formCard)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),

            // Pin contentView to the scroll view's content layout guide so
            // the content chain drives the scroll content size, not the frame.
            contentView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor),

            logoImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 40),
            logoImageView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            logoImageView.widthAnchor.constraint(equalTo: contentView.widthAnchor, multiplier: 0.55),
            logoImageView.heightAnchor.constraint(equalToConstant: 110),

            formCard.topAnchor.constraint(equalTo: logoImageView.bottomAnchor, constant: 32),
            formCard.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            formCard.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            formCard.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -40),

            cardStack.topAnchor.constraint(equalTo: formCard.topAnchor, constant: 24),
            cardStack.leadingAnchor.constraint(equalTo: formCard.leadingAnchor, constant: 20),
            cardStack.trailingAnchor.constraint(equalTo: formCard.trailingAnchor, constant: -20),
            cardStack.bottomAnchor.constraint(equalTo: formCard.bottomAnchor, constant: -24),

            signInButton.heightAnchor.constraint(equalToConstant: 44),
            separatorView.heightAnchor.constraint(equalToConstant: 1),
            liteSeparatorView.heightAnchor.constraint(equalToConstant: 1),
        ])
    }

    private func setupLoggedInUI() {
        view.addSubview(loggedInStack)

        NSLayoutConstraint.activate([
            loggedInLogoImageView.heightAnchor.constraint(equalToConstant: 110),
            loggedInLogoImageView.widthAnchor.constraint(equalToConstant: 200),

            logoutButton.widthAnchor.constraint(equalToConstant: 220),
            logoutButton.heightAnchor.constraint(equalToConstant: 44),

            loggedInStack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loggedInStack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            loggedInStack.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 40),
            loggedInStack.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -40),
        ])
    }

    // MARK: - Actions

    @objc func openScreenSet() {
        let screenSetId = "mpaturu-RegistrationLogin"

        Gigya.sharedInstance(CDCAccount.self).showScreenSet(
            with: screenSetId,
            viewController: self,
            params: ["lang": "en"]
        ) { [weak self] event in

            switch event {
            case .onAfterSubmit(let event):
                let screen = event["screen"] as? String ?? event["currentScreen"] as? String ?? ""

                if screen.contains("login"), Self.extractStatus(from: event) == "OK" {
                    // Login form submitted successfully.
                    // Web equivalent: call freshShopRegVerification() then redirect to home.
                    // In iOS we fetch the account (session already established) and
                    // transition home. The small delay matches the web's setTimeout(100)
                    // to let the SDK finish wiring the session before we read it.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                        self?.fetchAndShowAccount()
                    }
                } else if screen.contains("register") {
                    let errorCode = Self.extractErrorCode(from: event)
                    if errorCode == 206002 {
                        // Pending registration — email verification required.
                        // The screen-set switches to login internally; surface the
                        // success message as a toast that floats above the modal.
                        DispatchQueue.main.async {
                            self?.showToastBanner("Your profile has been successfully created.")
                        }
                    }
                    // errorCode == 0: full registration success — onLogin fires next.
                }

            case .onLogout:
                print("User logged out.")
                self?.showLoggedOutState()

            case .onCanceled:
                print("User cancelled the login flow.")

            case .error(let event):
                let code = event["errorCode"] ?? "n/a"
                let message = event["errorMessage"] ?? event["eventName"] ?? "unknown"
                print("Web Screen-Set error [\(code)]: \(message)")

            default:
                break
            }
        }
    }

    @objc func openRegistrationScreen() {
        Gigya.sharedInstance(CDCAccount.self).showScreenSet(
            with: "mpaturu-RegistrationLogin",
            viewController: self,
            params: ["lang": "en", "startScreen": "mpaturu-gigya-register-screen"]
        ) { [weak self] event in
            switch event {
            case .onAfterSubmit(let event):
                let screen = event["screen"] as? String ?? event["currentScreen"] as? String ?? ""
                let errorCode = Self.extractErrorCode(from: event)
                let status = Self.extractStatus(from: event)

                if screen.contains("register") {
                    if errorCode == 206002 {
                        // Pending registration — email verification required.
                        DispatchQueue.main.async {
                            self?.showToastBanner("Your profile has been successfully created.")
                        }
                    } else if errorCode == 0 || status == "OK" {
                        // Full registration success — user is auto-logged in, go to welcome screen.
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                            self?.fetchAndShowAccount()
                        }
                    }
                } else if screen.contains("login"), status == "OK" {
                    // Screen set transitioned to login after registration and auto-submitted.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                        self?.fetchAndShowAccount()
                    }
                }

            case .onLogin:
                // Fires when registration auto-logs the user in.
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                    self?.fetchAndShowAccount()
                }

            case .onCanceled:
                print("User cancelled registration.")

            case .error(let event):
                let code = event["errorCode"] ?? "n/a"
                let message = event["errorMessage"] ?? event["eventName"] ?? "unknown"
                print("Registration error [\(code)]: \(message)")

            default:
                break
            }
        }
    }

    @objc func openLiteRegistration() {
        Gigya.sharedInstance(CDCAccount.self).showScreenSet(
            with: "mpaturu-LiteRegistration",
            viewController: self,
            params: ["lang": "en", "startScreen": "mpaturu-gigya-subscribe-with-email-screen"]
        ) { [weak self] event in
            switch event {
            case .onAfterSubmit(let e):
                let errorCode = Self.extractErrorCode(from: e) ?? -1
                let status = Self.extractStatus(from: e)
                print("[CDC] LiteRegistration onAfterSubmit — status: \(status ?? "nil"), errorCode: \(errorCode)")
                if errorCode == 0 || status == "OK" {
                    DispatchQueue.main.async {
                        self?.showToastBanner("You have successfully subscribed.")
                    }
                }
            case .onLogin:
                // Lite registration created a session — show the logged-in welcome screen.
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                    self?.fetchAndShowAccount()
                }
            case .onCanceled:
                print("User cancelled lite registration.")
            case .error(let e):
                let code = e["errorCode"] ?? "n/a"
                let message = e["errorMessage"] ?? e["eventName"] ?? "unknown"
                print("Lite registration error [\(code)]: \(message)")
            default:
                break
            }
        }
    }

    @objc func openUpdateProfile() {
        var submitted = false
        Gigya.sharedInstance(CDCAccount.self).showScreenSet(
            with: "mpaturu-ProfileUpdate",
            viewController: self,
            params: ["lang": "en"]
        ) { [weak self] event in
            switch event {
            case .onAfterSubmit(let e):
                let screen = e["screen"] as? String ?? e["currentScreen"] as? String ?? ""
                let status = Self.extractStatus(from: e) ?? "nil"
                print("[CDC] ProfileUpdate onAfterSubmit — screen: \(screen), status: \(status)")
                submitted = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                    self?.fetchAndShowAccount()
                }
            case .onHide:
                // Fallback: refresh if the screen set closed after a successful submit
                // but fetchAndShowAccount wasn't triggered yet.
                if submitted { break }
            case .error(let e):
                let code = e["errorCode"] ?? "n/a"
                let message = e["errorMessage"] ?? e["eventName"] ?? "unknown"
                print("Profile update error [\(code)]: \(message)")
            default:
                break
            }
        }
    }

    @objc func logout() {
        Gigya.sharedInstance(CDCAccount.self).logout()
        showLoggedOutState()
    }

    // MARK: - UI State

    // MARK: - getAccountInfo equivalent (mirrors web gigya.accounts.getAccountInfo callback)

    private func showLoggedInState(with account: CDCAccount) {
        let profile = account.profile

        // Name resolution mirrors web: fullName || firstName || nickname || "User"
        let fullName = [profile?.firstName, profile?.lastName]
            .compactMap { $0?.isEmpty == false ? $0 : nil }
            .joined(separator: " ")
        let displayName = !fullName.isEmpty
            ? fullName
            : profile?.firstName ?? profile?.nickname ?? "User"

        let email = profile?.email ?? ""
        let artsCustKey = account.data?.ARTS_CUST_KEY  // res.data['ARTS_CUST_KEY']

        print("[CDC] getAccountInfo — UID: \(account.UID ?? ""), email: \(email), name: \(displayName), ARTS_CUST_KEY: \(artsCustKey ?? "nil")")

        // Mirror the web's post-login ScarabQueue calls — one bundled request via go().
        if !email.isEmpty {
            ScarabTracker.push(email: email)                                                    // ScarabQueue.push(['setEmail', email])
        }
        if let custKey = artsCustKey, !custKey.isEmpty {
            ScarabTracker.push(customerId: custKey)                                             // ScarabQueue.push(['setCustomerId', ARTS_CUST_KEY])
        }
        ScarabTracker.push(category: "account")                                                 // ScarabQueue.push(['category', "account"])
        ScarabTracker.push(item: "SKU-001")                                                     // ScarabQueue.push(['view', "SKU-001"])
        ScarabTracker.push(search: "running shoes")                                             // ScarabQueue.push(['searchTerm', "running shoes"])
        ScarabTracker.push(cart: [(itemId: "SKU-001", price: 79.99, quantity: 1)])              // ScarabQueue.push(['cart', [...]])
        ScarabTracker.push(purchase: "ORDER-12345",                                             // ScarabQueue.push(['purchase', {...}])
                           items: [(itemId: "SKU-001", price: 79.99, quantity: 2)])
        ScarabTracker.go()                                                                      // ScarabQueue.push(['go'])

        welcomeNameLabel.text = "Welcome, \(displayName)!"
        accountDetailsLabel.text = "Email: \(email.isEmpty ? "—" : email)"

        scrollView.isHidden = true
        loggedInStack.isHidden = false
    }

    private func showLoggedOutState() {
        scrollView.isHidden = false
        loggedInStack.isHidden = true
    }

    /// Extracts `errorCode` from an onAfterSubmit event.
    /// The value may be a direct Int/String key, or nested inside a JSON "response" string.
    private static func extractErrorCode(from event: PluginEventData) -> Int? {
        if let code = event["errorCode"] as? Int { return code }
        if let str = event["errorCode"] as? String, let code = Int(str) { return code }
        if let responseStr = event["response"] as? String,
           let data = responseStr.data(using: .utf8),
           let dict = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            if let code = dict["errorCode"] as? Int { return code }
            if let str = dict["errorCode"] as? String, let code = Int(str) { return code }
        }
        return nil
    }

    /// Extracts `status` from an onAfterSubmit event (e.g. "OK").
    /// Mirrors the web check `e.response.status === 'OK'`.
    private static func extractStatus(from event: PluginEventData) -> String? {
        if let status = event["status"] as? String { return status }
        if let responseStr = event["response"] as? String,
           let data = responseStr.data(using: .utf8),
           let dict = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            return dict["status"] as? String
        }
        return nil
    }

    /// iOS equivalent of `gigya.accounts.getAccountInfo({ callback })`.
    /// Called on app start (viewDidLoad) and after every successful login/registration.
    private func fetchAndShowAccount() {
        Gigya.sharedInstance(CDCAccount.self).getAccount(true) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let account):
                    // errorCode === 0 — logged in
                    self?.showLoggedInState(with: account)
                case .failure:
                    // errorCode !== 0 — not logged in or session expired
                    self?.showLoggedOutState()
                }
            }
        }
    }
}

// MARK: - Scarab / Emarsys Predict tracker

// iOS equivalent of the web's ScarabQueue pattern.
// push() queues params; go() sends them all in one request —
// mirroring ScarabQueue.push([...]) + ScarabQueue.push(['go']).
// Calls recommender.scarabresearch.com directly (no EmarsysSDK needed).
// Query param keys sourced from EMSPredictInternal + EMSCartItemUtils.
private enum ScarabTracker {
    private static let merchantId = "13A8187A265F1E7A"
    private static let baseURL    = "https://recommender.scarabresearch.com/merchants/"
    private static let visitorKey = "com.commissary.scarab.visitorId"

    // Queued params — flushed as a single request when go() is called.
    private static var queue: [URLQueryItem] = []

    // Stable visitor ID persisted across sessions — equivalent of Scarab's browser cookie.
    private static var visitorId: String {
        if let id = UserDefaults.standard.string(forKey: visitorKey) { return id }
        let id = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
        UserDefaults.standard.set(id, forKey: visitorKey)
        return id
    }

    // ScarabQueue.push(['setEmail', email])
    // Web hashes: sha1(trim(email).toLowerCase())[0..15] + "1" → sent as eh=
    static func push(email: String) {
        let normalized = email.trimmingCharacters(in: .whitespaces).lowercased()
        let digest = Insecure.SHA1.hash(data: Data(normalized.utf8))
        let hex = digest.map { String(format: "%02x", $0) }.joined()
        let emailHash = String(hex.prefix(16)) + "1"
        queue.append(URLQueryItem(name: "eh", value: emailHash))
    }

    // ScarabQueue.push(['setCustomerId', customerId])
    static func push(customerId: String) {
        queue.append(URLQueryItem(name: "ci", value: customerId))
    }

    // ScarabQueue.push(['category', path])
    static func push(category path: String) {
        queue.append(URLQueryItem(name: "vc", value: path))
    }

    // ScarabQueue.push(['view', itemId])
    static func push(item itemId: String) {
        queue.append(URLQueryItem(name: "v", value: "i:\(itemId)"))
    }

    // ScarabQueue.push(['searchTerm', term])
    static func push(search term: String) {
        queue.append(URLQueryItem(name: "q", value: term))
    }

    // ScarabQueue.push(['cart', [{ item, price, quantity }]])
    // Format: cv=1&ca=i:SKU-001,p:79.99,q:1|i:SKU-002,p:49.99,q:2
    static func push(cart items: [(itemId: String, price: Double, quantity: Int)]) {
        let ca = items.map { "i:\($0.itemId),p:\($0.price),q:\($0.quantity)" }.joined(separator: "|")
        queue.append(URLQueryItem(name: "cv", value: "1"))
        queue.append(URLQueryItem(name: "ca", value: ca))
    }

    // ScarabQueue.push(['purchase', { orderId, items: [{ item, price, quantity }] }])
    // Format: co=i:SKU-001,p:79.99,q:2&oi=ORDER-12345
    static func push(purchase orderId: String, items: [(itemId: String, price: Double, quantity: Int)]) {
        let co = items.map { "i:\($0.itemId),p:\($0.price),q:\($0.quantity)" }.joined(separator: "|")
        queue.append(URLQueryItem(name: "co", value: co))
        queue.append(URLQueryItem(name: "oi", value: orderId))
    }

    // ScarabQueue.push(['go']) — flush all queued params in one HTTP request.
    static func go() {
        let params = queue
        queue = []
        guard !params.isEmpty else { return }

        var components = URLComponents(string: baseURL + merchantId)!
        components.queryItems = [
            URLQueryItem(name: "cp", value: "1"),
            URLQueryItem(name: "vi", value: visitorId),
        ] + params
        guard let url = components.url else { return }

        URLSession.shared.dataTask(with: url) { _, response, _ in
            if let http = response as? HTTPURLResponse {
                let keys = params.map { $0.name }.joined(separator: "+")
                print("[Scarab] go(\(keys)) → \(http.statusCode)")
            }
        }.resume()
    }
}
