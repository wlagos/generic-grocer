pluginManagement {
    repositories {
        maven { url = uri("local-maven") }  // local offline repo — avoids network 403s
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven { url = uri("local-maven") }  // local offline repo — avoids network 403s
        google()
        mavenCentral()
    }
}

rootProject.name = "MpTest0916"
include(":app")
 