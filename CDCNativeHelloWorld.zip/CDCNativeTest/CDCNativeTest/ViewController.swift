//  ViewController.swift
//  CDCNativeTest
//

import UIKit
import Gigya
import GigyaNss // Successfully linked via CocoaPods

class ViewController: UIViewController {

    // MARK: - UI

    private let loginButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Open Registration/Login", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let statusLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 18)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    private let logoutButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Logout", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        loginButton.addTarget(self, action: #selector(openScreenSet), for: .touchUpInside)
        logoutButton.addTarget(self, action: #selector(logout), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [statusLabel, loginButton, logoutButton])
        stack.axis = .vertical
        stack.spacing = 24
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24)
        ])

        // Reflect the current session state on launch.
        if Gigya.sharedInstance(GigyaAccount.self).isLoggedIn() {
            showLoggedInState(for: nil)
            Gigya.sharedInstance(GigyaAccount.self).getAccount { [weak self] result in
                DispatchQueue.main.async {
                    if case .success(let account) = result {
                        self?.showLoggedInState(for: account)
                    }
                }
            }
        } else {
            showLoggedOutState()
        }
    }

    // MARK: - Actions

    @objc func openScreenSet() {
        GigyaNss.shared
            .load(screenSetId: "mpaturu-RegistrationLogin-Native")
            .initialRoute(name: "login")
            .lang(name: "en")
            .events(GigyaAccount.self) { [weak self] result in
                switch result {
                case .success(let screenId, let action, let account):
                    print("Successfully completed '\(action.rawValue)' on screen \(screenId ?? "")")
                    print("User UID: \(account?.UID ?? "")")
                    DispatchQueue.main.async {
                        if action == .register {
                            // A brand-new account was created. Registration
                            // auto-creates a session, so clear it and prompt the
                            // user to log in, matching the web-screens flow.
                            self?.handleAccountCreated()
                        } else {
                            // Dismiss the screen-set, then show our success state.
                            self?.dismiss(animated: true) {
                                self?.showLoggedInState(for: account)
                            }
                        }
                    }

                case .error(let screenId, let error):
                    self?.logScreenSetError(screenId: screenId, error: error)

                case .canceled:
                    print("User manually swiped down or dismissed the login layout.")

                @unknown default:
                    // This handles any future additions safely
                    print("An unexpected case was received.")
                }
            }
            .show(viewController: self)
    }

    @objc func logout() {
        Gigya.sharedInstance(GigyaAccount.self).logout { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success:
                    print("Logout successful")
                case .failure(let error):
                    print("Logout failed: \(error)")
                }
                // Return to the logged-out state regardless; the local
                // session is cleared as part of logout.
                self?.showLoggedOutState()
            }
        }
    }

    /// Handles a successful registration: clears the auto-created session,
    /// returns to the logged-out state, dismisses the screen-set, and shows a
    /// success message with an option to log in.
    private func handleAccountCreated() {
        Gigya.sharedInstance(GigyaAccount.self).logout()
        showLoggedOutState()

        // The screen-set is presented on top of us; dismiss it first, then show
        // the success message so the alert isn't blocked.
        if let presented = presentedViewController {
            presented.dismiss(animated: true) { [weak self] in
                self?.showAccountCreatedAlert()
            }
        } else {
            showAccountCreatedAlert()
        }
    }

    private func showAccountCreatedAlert() {
        let alert = UIAlertController(
            title: "Account Created Successfully",
            message: "Your account was created. Please log in to continue.",
            preferredStyle: .alert
        )
        // Give the user a direct link back into the login screen-set.
        alert.addAction(UIAlertAction(title: "Log In", style: .default) { [weak self] _ in
            self?.openScreenSet()
        })
        alert.addAction(UIAlertAction(title: "Not Now", style: .cancel))
        present(alert, animated: true)
    }

    // MARK: - Error Logging

    /// Unwraps a Gigya `NetworkError` so the real server error code/message is
    /// visible instead of the generic "NetworkError error 0" description.
    private func logScreenSetError(screenId: String?, error: NetworkError) {
        let screen = screenId ?? ""
        switch error {
        case .gigyaError(let data):
            print("Screen-Set error on '\(screen)' — code: \(data.errorCode), message: \(data.errorMessage ?? "n/a"), callId: \(data.callId)")
            // For validation errors (400009) the server includes a
            // `validationErrors` array naming the exact field(s) that failed.
            let response = data.toDictionary()
            if let validationErrors = response["validationErrors"] {
                print("  validationErrors: \(validationErrors)")
            } else {
                print("  full response: \(response)")
            }
        case .providerError(let data):
            print("Screen-Set provider error on '\(screen)': \(data)")
        case .networkError(let underlying):
            print("Screen-Set network error on '\(screen)': \(underlying.localizedDescription)")
        case .jsonParsingError(let underlying):
            print("Screen-Set JSON parsing error on '\(screen)': \(underlying.localizedDescription)")
        case .emptyResponse:
            print("Screen-Set error on '\(screen)': empty response")
        case .createURLRequestFailed:
            print("Screen-Set error on '\(screen)': failed to create URL request")
        @unknown default:
            print("Screen-Set error on '\(screen)': \(error.localizedDescription)")
        }
    }

    // MARK: - UI State

    private func showLoggedInState(for account: GigyaAccount?) {
        let name = [account?.profile?.firstName, account?.profile?.lastName]
            .compactMap { $0 }
            .joined(separator: " ")
        let email = account?.profile?.email ?? ""

        var message = "You are logged in successfully!"
        if !name.isEmpty {
            message += "\n\nWelcome, \(name)"
        }
        if !email.isEmpty {
            message += "\n\(email)"
        }

        statusLabel.text = message
        statusLabel.isHidden = false
        loginButton.isHidden = true
        logoutButton.isHidden = false
    }

    private func showLoggedOutState() {
        statusLabel.text = nil
        statusLabel.isHidden = true
        loginButton.isHidden = false
        logoutButton.isHidden = true
    }
}
