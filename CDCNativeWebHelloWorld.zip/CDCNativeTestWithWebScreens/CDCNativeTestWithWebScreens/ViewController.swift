//
//  ViewController.swift
//  CDCNativeTest
//

import UIKit
import Gigya

class ViewController: UIViewController {

    // MARK: - UI

    private let loginButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Open Registration/Login", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    private let successTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "✅ You're logged in!"
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()

    private let detailsLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = .secondaryLabel
        return label
    }()

    private let logoutButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Log Out", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        return button
    }()

    private lazy var loggedInStack: UIStackView = {
        let stack = UIStackView(arrangedSubviews: [successTitleLabel, detailsLabel, logoutButton])
        stack.axis = .vertical
        stack.spacing = 20
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()

    // MARK: - State

    /// The screen the user is currently on inside the screen-set, used to tell a
    /// registration apart from a login (both surface as `.onLogin`).
    private var currentScreen: String?

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        loginButton.addTarget(self, action: #selector(openScreenSet), for: .touchUpInside)
        logoutButton.addTarget(self, action: #selector(logout), for: .touchUpInside)

        view.addSubview(loginButton)
        view.addSubview(loggedInStack)

        NSLayoutConstraint.activate([
            loginButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loginButton.centerYAnchor.constraint(equalTo: view.centerYAnchor),

            loggedInStack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            loggedInStack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            loggedInStack.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 40),
            loggedInStack.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -40),
        ])

        // Reflect an existing session (e.g. after relaunch) on load.
        if Gigya.sharedInstance().isLoggedIn() {
            fetchAndShowAccount()
        } else {
            showLoggedOutState()
        }
    }

    // MARK: - Actions

    @objc func openScreenSet() {

        // Replace with your actual Web Screen-Set ID from SAP CDC Console
        let screenSetId = "mpaturu-RegistrationLogin"

        Gigya.sharedInstance().showScreenSet(
            with: screenSetId,
            viewController: self,
            params: ["lang": "en"]
        ) { [weak self] event in

            switch event {
            case .onAfterScreenLoad(let event):
                // Track which screen is showing (e.g. gigya-login-screen /
                // gigya-register-screen) to distinguish registration from login.
                self?.currentScreen = event["currentScreen"] as? String

            case .onLogin(let account):
                if self?.currentScreen?.lowercased().contains("register") == true {
                    // A brand-new account was created. Registration auto-creates a
                    // session, so clear it and return to the login screen with a
                    // success message.
                    print("Account created for UID: \(account.UID ?? "")")
                    self?.handleAccountCreated()
                } else {
                    print("Successfully logged in user UID: \(account.UID ?? "")")
                    self?.showLoggedInState(with: account)
                }

            case .onLogout:
                print("User logged out.")
                self?.showLoggedOutState()

            case .onCanceled:
                print("User cancelled the login flow.")

            case .error(let event):
                let code = event["errorCode"] ?? "n/a"
                let message = event["errorMessage"] ?? event["eventName"] ?? "unknown"
                print("Web Screen-Set error [\(code)]: \(message)")
                print("Full error event: \(event)")

            default:
                // Other lifecycle events (screen load, field changed, etc.)
                break
            }
        }
    }

    @objc func logout() {
        Gigya.sharedInstance().logout()
        showLoggedOutState()
    }

    // MARK: - UI State

    private func showLoggedInState(with account: GigyaAccount) {
        let firstName = account.profile?.firstName ?? ""
        let lastName = account.profile?.lastName ?? ""
        let fullName = "\(firstName) \(lastName)".trimmingCharacters(in: .whitespaces)
        let email = account.profile?.email ?? "—"
        let uid = account.UID ?? "—"

        successTitleLabel.text = fullName.isEmpty ? "✅ You're logged in!" : "✅ Welcome, \(fullName)!"
        detailsLabel.text = "Email: \(email)\nUID: \(uid)"

        loginButton.isHidden = true
        loggedInStack.isHidden = false
    }

    private func showLoggedOutState() {
        loginButton.isHidden = false
        loggedInStack.isHidden = true
    }

    /// Handles a successful registration: clears the auto-created session, returns
    /// to the login screen, and shows a success message with a login option.
    private func handleAccountCreated() {
        Gigya.sharedInstance().logout()
        showLoggedOutState()

        // The screen-set is presented as a sheet on top of us; dismiss it first,
        // then show the success message so the alert isn't blocked.
        if let presented = presentedViewController {
            presented.dismiss(animated: true) { [weak self] in
                self?.showAccountCreatedAlert()
            }
        } else {
            showAccountCreatedAlert()
        }
    }

    private func showAccountCreatedAlert() {
        let alert = UIAlertController(
            title: "Account Created Successfully",
            message: "Your account was created. Please log in to continue.",
            preferredStyle: .alert
        )
        // Give the user a direct link to the login screen-set.
        alert.addAction(UIAlertAction(title: "Log In", style: .default) { [weak self] _ in
            self?.openScreenSet()
        })
        alert.addAction(UIAlertAction(title: "Not Now", style: .cancel))
        present(alert, animated: true)
    }

    /// Loads the current account for an already-authenticated session.
    private func fetchAndShowAccount() {
        Gigya.sharedInstance().getAccount { [weak self] result in
            switch result {
            case .success(let account):
                self?.showLoggedInState(with: account)
            case .failure:
                self?.showLoggedOutState()
            }
        }
    }
}
