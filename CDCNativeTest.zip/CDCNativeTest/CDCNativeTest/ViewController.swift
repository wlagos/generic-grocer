//  ViewController.swift
//  CDCNativeTest
//

import UIKit
import Gigya
import GigyaNss // Successfully linked via CocoaPods

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        // Add a button to open the Screen-Set
        let button = UIButton(type: .system)
        button.setTitle("Open Registration/Login", for: .normal)
        button.addTarget(self, action: #selector(openScreenSet), for: .touchUpInside)
        button.frame = CGRect(x: 40, y: 200, width: 300, height: 50)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        view.addSubview(button)
    }

    @objc func openScreenSet() {
        GigyaNss.shared
            .load(screenSetId: "mpaturu-RegistrationLogin-Native")
            .initialRoute(name: "login")
            .lang(name: "en")
            .events(GigyaAccount.self) { [weak self] result in
                switch result {
                case .success(let screenId, let action, let account):
                    print("Successfully authenticated on screen \(screenId ?? "")")
                    print("Logged in user UID: \(account?.UID ?? "")")
                    
                case .error(let screenId, let error):
                    print("Native Screen-Set compile error on screen \(screenId ?? ""): \(error.localizedDescription)")
                    
                case .canceled:
                    print("User manually swiped down or dismissed the login layout.")
                    
                @unknown default:
                    // This handles any future additions safely
                    print("An unexpected case was received.")
                }
            }
            .show(viewController: self)
    }


}

